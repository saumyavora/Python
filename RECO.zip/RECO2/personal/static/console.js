$(function(){
    console.log("working");
})